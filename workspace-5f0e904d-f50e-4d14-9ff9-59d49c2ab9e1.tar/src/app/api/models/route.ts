import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  try {
    // Define available text models
    const textModels = [
      { id: 'gpt-5-nano', name: 'GPT-5 Nano' },
      { id: 'gpt-5', name: 'GPT-5' },
      { id: 'gpt-5-turbo', name: 'GPT-5 Turbo' },
      { id: 'gpt-5-pro', name: 'GPT-5 Pro' },
      { id: 'claude-3-haiku', name: 'Claude 3 Haiku' },
      { id: 'claude-3-sonnet', name: 'Claude 3 Sonnet' },
      { id: 'claude-3-opus', name: 'Claude 3 Opus' },
      { id: 'llama-3-8b', name: 'Llama 3 8B' },
      { id: 'llama-3-70b', name: 'Llama 3 70B' }
    ];
    
    // Define available image models
    const imageModels = [
      { id: 'flux', name: 'Flux' },
      { id: 'midjourney', name: 'Midjourney' },
      { id: 'dall-e-3', name: 'DALL-E 3' },
      { id: 'stable-diffusion', name: 'Stable Diffusion' },
      { id: 'sdxl', name: 'SDXL' }
    ];
    
    return NextResponse.json({
      success: true,
      models: {
        text: textModels,
        image: imageModels,
        audio: [
          { id: 'openai-tts', name: 'OpenAI TTS', voices: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] }
        ]
      }
    });
  } catch (error) {
    return NextResponse.json(
      { 
        error: 'Failed to fetch models',
        details: error instanceof Error ? error.message : 'Unknown error',
        models: {
          text: [
            { id: 'gpt-5-nano', name: 'GPT-5 Nano' }
          ],
          image: [
            { id: 'flux', name: 'Flux' }
          ],
          audio: [
            { id: 'openai-tts', name: 'OpenAI TTS', voices: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] }
          ]
        }
      },
      { status: 500 }
    );
  }
}