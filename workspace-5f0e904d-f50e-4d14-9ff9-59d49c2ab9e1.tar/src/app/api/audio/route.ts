import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const prompt = searchParams.get('prompt');
    const voice = searchParams.get('voice') || 'alloy';
    
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // Try multiple audio endpoints to find one that works
    const audioEndpoints = [
      `https://audio.pollinations.ai/${encodeURIComponent(prompt)}?voice=${voice}`,
      `https://text.pollinations.ai/${encodeURIComponent(prompt)}?voice=${voice}&model=openai-tts`,
      `https://text.pollinations.ai/${encodeURIComponent(prompt)}?model=openai-tts&voice=${voice}`
    ];

    let audioResponse;
    let workingUrl = '';
    
    for (const url of audioEndpoints) {
      try {
        console.log('Trying audio endpoint:', url);
        audioResponse = await fetch(url, {
          signal: AbortSignal.timeout(30000) // 30 second timeout
        });
        
        if (audioResponse.ok) {
          workingUrl = url;
          break;
        }
      } catch (error) {
        console.log('Audio endpoint failed:', url, error);
        continue;
      }
    }
    
    if (!audioResponse || !audioResponse.ok) {
      throw new Error('All audio endpoints failed');
    }

    // Get the audio content type
    const contentType = audioResponse.headers.get('content-type') || 'audio/mpeg';

    return NextResponse.json({
      success: true,
      audioUrl: workingUrl,
      contentType,
      prompt,
      voice
    });
  } catch (error) {
    console.error('Audio generation error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate audio',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}