import { NextRequest, NextResponse } from 'next/server';

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenAIRequest {
  model?: string;
  messages: OpenAIMessage[];
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
}

export async function POST(request: NextRequest) {
  try {
    const body: OpenAIRequest = await request.json();
    const { messages, temperature = 0.7, max_tokens = 1000, model = 'gpt-3.5-turbo' } = body;
    
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: 'Messages are required and must be an array' },
        { status: 400 }
      );
    }

    // Convert messages to a single prompt for Pollinations.AI
    const prompt = messages
      .map(msg => `${msg.role}: ${msg.content}`)
      .join('\n');

    const response = await fetch('https://text.pollinations.ai/openai', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages,
        temperature,
        max_tokens
      }),
      timeout: 30000
    });
    
    if (!response.ok) {
      throw new Error(`Failed to generate response: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Extract content from the response
    let content = '';
    if (data.text) {
      content = data.text;
    } else if (data.choices && data.choices[0] && data.choices[0].message) {
      content = data.choices[0].message.content;
    } else if (data.content) {
      content = data.content;
    } else {
      content = 'No response generated';
    }
    
    // Transform response to OpenAI format
    const openAIResponse = {
      id: `chatcmpl-${Date.now()}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content
          },
          finish_reason: 'stop'
        }
      ],
      usage: {
        prompt_tokens: prompt.length,
        completion_tokens: content.length,
        total_tokens: prompt.length + content.length
      }
    };
    
    return NextResponse.json(openAIResponse);
  } catch (error) {
    return NextResponse.json(
      { 
        error: 'Failed to generate response',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}