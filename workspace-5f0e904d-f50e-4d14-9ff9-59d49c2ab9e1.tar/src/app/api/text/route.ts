import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const prompt = searchParams.get('prompt');
    
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    const response = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`, {
      headers: {
        'Accept': 'text/plain',
      },
    });
    
    if (!response.ok) {
      throw new Error(`Failed to generate text: ${response.status} ${response.statusText}`);
    }

    const text = await response.text();
    
    return NextResponse.json({
      success: true,
      text,
      prompt
    });
  } catch (error) {
    return NextResponse.json(
      { 
        error: 'Failed to generate text',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, model = 'gpt-5-nano' } = body;
    
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // Try POST request first with proper model handling
    try {
      const response = await fetch('https://text.pollinations.ai/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/plain',
        },
        body: JSON.stringify({
          prompt,
          model
        }),
        signal: AbortSignal.timeout(30000) // 30 second timeout
      });
      
      if (response.ok) {
        const text = await response.text();
        return NextResponse.json({
          success: true,
          text,
          prompt,
          model
        });
      }
    } catch (postError) {
      console.log('POST request failed, trying GET:', postError);
    }

    // Fallback to GET request with model parameter
    const getResponse = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}?model=${model}`, {
      headers: {
        'Accept': 'text/plain',
      },
      signal: AbortSignal.timeout(30000) // 30 second timeout
    });
    
    if (!getResponse.ok) {
      // Try without model parameter as fallback
      const fallbackResponse = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`, {
        headers: {
          'Accept': 'text/plain',
        },
        signal: AbortSignal.timeout(30000)
      });
      
      if (!fallbackResponse.ok) {
        throw new Error(`Failed to generate text: ${getResponse.status} ${getResponse.statusText}`);
      }
      
      const text = await fallbackResponse.text();
      return NextResponse.json({
        success: true,
        text,
        prompt,
        model: 'default'
      });
    }

    const text = await getResponse.text();
    
    return NextResponse.json({
      success: true,
      text,
      prompt,
      model
    });
  } catch (error) {
    console.error('Text generation error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate text',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}