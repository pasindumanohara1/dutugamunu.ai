import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type') || 'text';
  const limit = parseInt(searchParams.get('limit') || '10');
  
  try {
    let feedUrl;
    if (type === 'image') {
      feedUrl = 'https://image.pollinations.ai/feed';
    } else {
      feedUrl = 'https://text.pollinations.ai/feed';
    }
    
    const response = await fetch(feedUrl, {
      headers: { 'Accept': 'application/json' },
      timeout: 5000
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch ${type} feed: ${response.status} ${response.statusText}`);
    }

    let feed = await response.json();
    
    // Ensure feed is an array
    if (!Array.isArray(feed)) {
      feed = [];
    }
    
    // Limit the number of items returned
    const limitedFeed = feed.slice(0, limit);
    
    return NextResponse.json({
      success: true,
      type,
      feed: limitedFeed,
      limit,
      total: feed.length
    });
  } catch (error) {
    return NextResponse.json(
      { 
        error: `Failed to fetch ${type} feed`,
        details: error instanceof Error ? error.message : 'Unknown error',
        feed: [],
        limit: 0,
        total: 0
      },
      { status: 500 }
    );
  }
}