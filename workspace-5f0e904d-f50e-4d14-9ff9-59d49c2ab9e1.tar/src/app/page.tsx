"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Image, Music, List, Settings, MessageSquare, Sparkles, Download, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  type: "user" | "assistant";
  content: string;
  timestamp: Date;
  mediaType?: "text" | "image" | "audio";
  mediaUrl?: string;
  contentType?: string;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

interface Model {
  id: string;
  name: string;
  type: "text" | "image" | "audio";
}

export default function Home() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const [selectedModel, setSelectedModel] = useState("text");
  const [selectedVoice, setSelectedVoice] = useState("alloy");
  const [selectedTextModel, setSelectedTextModel] = useState("gpt-5-nano");
  const [imageSize, setImageSize] = useState("1024x1024");
  const [availableModels, setAvailableModels] = useState<{
    text: any[];
    image: any[];
    audio: any[];
  }>({ text: [], image: [], audio: [] });
  const [loadingModels, setLoadingModels] = useState(true);
  const [feeds, setFeeds] = useState<{
    text: any[];
    image: any[];
  }>({ text: [], image: [] });
  const [loadingFeeds, setLoadingFeeds] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const voices = [
    { id: "alloy", name: "Alloy" },
    { id: "echo", name: "Echo" },
    { id: "fable", name: "Fable" },
    { id: "onyx", name: "Onyx" },
    { id: "nova", name: "Nova" },
    { id: "shimmer", name: "Shimmer" },
  ];

  const imageSizes = [
    { id: "256x256", name: "256x256" },
    { id: "512x512", name: "512x512" },
    { id: "1024x1024", name: "1024x1024" },
    { id: "1024x1792", name: "1024x1792" },
    { id: "1792x1024", name: "1792x1024" },
  ];

  const downloadImage = async (imageUrl: string, filename: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      console.error('Failed to download image:', error);
      toast({
        title: "Download Failed",
        description: "Failed to download the image. Please try again.",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      // Fallback for browsers that don't support clipboard API
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        // Use the old-school document.execCommand method
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        textArea.remove();
      }
      toast({
        title: "Copied to clipboard",
        description: "Text has been copied to your clipboard.",
      });
    } catch (error) {
      console.error('Failed to copy text:', error);
      toast({
        title: "Copy Failed",
        description: "Failed to copy text to clipboard. Please copy manually.",
        variant: "destructive",
      });
    }
  };

  const stopGeneration = () => {
    if (abortController) {
      abortController.abort();
      setAbortController(null);
      setIsGenerating(false);
      setIsLoading(false);
      toast({
        title: "Generation Stopped",
        description: "Content generation has been stopped.",
      });
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const fetchModels = async () => {
      try {
        const response = await fetch('/api/models');
        const data = await response.json();
        
        if (data.success) {
          setAvailableModels(data.models);
        }
      } catch (error) {
        console.error('Failed to fetch models:', error);
      } finally {
        setLoadingModels(false);
      }
    };

    const fetchFeeds = async () => {
      try {
        const [textFeedResponse, imageFeedResponse] = await Promise.all([
          fetch('/api/feeds?type=text&limit=5'),
          fetch('/api/feeds?type=image&limit=5')
        ]);

        const textFeedData = await textFeedResponse.json();
        const imageFeedData = await imageFeedResponse.json();

        if (textFeedData.success) {
          setFeeds(prev => ({ ...prev, text: textFeedData.feed }));
        }
        if (imageFeedData.success) {
          setFeeds(prev => ({ ...prev, image: imageFeedData.feed }));
        }
      } catch (error) {
        console.error('Failed to fetch feeds:', error);
      } finally {
        setLoadingFeeds(false);
      }
    };

    fetchModels();
    fetchFeeds();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    // Create new conversation if none exists
    if (!currentConversationId) {
      createNewConversation(input.slice(0, 50) + (input.length > 50 ? '...' : ''));
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const currentInput = input;
    setInput("");
    setIsLoading(true);
    setIsGenerating(true);

    // Create abort controller
    const controller = new AbortController();
    setAbortController(controller);

    try {
      let response;
      let mediaType: "text" | "image" | "audio" = "text";
      let mediaUrl: string | undefined;
      let contentType: string | undefined;

      if (selectedModel === "image") {
        // Generate image using our API
        const [width, height] = imageSize.split('x');
        const imageResponse = await fetch(`/api/image?prompt=${encodeURIComponent(currentInput)}&width=${width}&height=${height}`, {
          signal: controller.signal
        });
        
        if (!imageResponse.ok) {
          throw new Error(`Image generation failed: ${imageResponse.status}`);
        }
        
        const imageData = await imageResponse.json();
        
        if (imageData.success) {
          mediaUrl = imageData.imageUrl;
          mediaType = "image";
          response = "Image generated successfully!";
        } else {
          throw new Error(imageData.error || 'Failed to generate image');
        }
      } else if (selectedModel === "audio") {
        // Generate audio using our API
        const audioResponse = await fetch(`/api/audio?prompt=${encodeURIComponent(currentInput)}&voice=${selectedVoice}`, {
          signal: controller.signal
        });
        
        if (!audioResponse.ok) {
          throw new Error(`Audio generation failed: ${audioResponse.status}`);
        }
        
        const audioData = await audioResponse.json();
        
        if (audioData.success) {
          mediaUrl = audioData.audioUrl;
          mediaType = "audio";
          response = "Audio generated successfully!";
          contentType = audioData.contentType;
        } else {
          throw new Error(audioData.error || 'Failed to generate audio');
        }
      } else {
        // Generate text using our API
        const textResponse = await fetch('/api/text', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: currentInput,
            model: selectedTextModel
          }),
          signal: controller.signal
        });
        
        if (!textResponse.ok) {
          throw new Error(`Text generation failed: ${textResponse.status}`);
        }
        
        const textData = await textResponse.json();
        
        if (textData.success) {
          response = textData.text;
          mediaType = "text";
        } else {
          throw new Error(textData.error || 'Failed to generate text');
        }
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: response,
        timestamp: new Date(),
        mediaType,
        mediaUrl,
        contentType
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Generation was aborted');
        return;
      }
      console.error('Generation error:', error);
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate response. Please try again.",
        variant: "destructive",
      });
      
      // Remove the user message if generation failed
      setMessages((prev) => prev.filter(msg => msg.id !== userMessage.id));
    } finally {
      setIsLoading(false);
      setIsGenerating(false);
      setAbortController(null);
    }
  };

  const clearChat = () => {
    setMessages([]);
    setCurrentConversationId(null);
  };

  // Conversation management functions
  const saveConversationsToStorage = (convs: Conversation[]) => {
    localStorage.setItem('pollinations-conversations', JSON.stringify(convs));
  };

  const loadConversationsFromStorage = (): Conversation[] => {
    const stored = localStorage.getItem('pollinations-conversations');
    
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        return parsed.map((conv: any) => ({
          ...conv,
          createdAt: new Date(conv.createdAt),
          updatedAt: new Date(conv.updatedAt),
          messages: conv.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
      } catch (error) {
        console.error('Failed to parse conversations:', error);
        return [];
      }
    }
    return [];
  };

  const createNewConversation = (title?: string) => {
    const newConversation: Conversation = {
      id: Date.now().toString(),
      title: title || `Conversation ${conversations.length + 1}`,
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const updatedConversations = [...conversations, newConversation];
    setConversations(updatedConversations);
    setCurrentConversationId(newConversation.id);
    setMessages([]);
    saveConversationsToStorage(updatedConversations);
  };

  const saveCurrentConversation = () => {
    if (!currentConversationId || messages.length === 0) return;

    const updatedConversations = conversations.map(conv => {
      if (conv.id === currentConversationId) {
        return {
          ...conv,
          messages,
          updatedAt: new Date(),
          title: conv.title.startsWith('Conversation') && messages.length > 0 
            ? messages[0].content.slice(0, 50) + (messages[0].content.length > 50 ? '...' : '')
            : conv.title
        };
      }
      return conv;
    });

    setConversations(updatedConversations);
    saveConversationsToStorage(updatedConversations);
  };

  const loadConversation = (conversationId: string) => {
    const conversation = conversations.find(conv => conv.id === conversationId);
    if (conversation) {
      setCurrentConversationId(conversationId);
      setMessages(conversation.messages);
    } else {
      console.error('Conversation not found for ID:', conversationId);
    }
  };

  const deleteConversation = (conversationId: string) => {
    const updatedConversations = conversations.filter(conv => conv.id !== conversationId);
    setConversations(updatedConversations);
    saveConversationsToStorage(updatedConversations);
    
    if (currentConversationId === conversationId) {
      setCurrentConversationId(null);
      setMessages([]);
    }
  };

  // Load conversations on mount
  useEffect(() => {
    const savedConversations = loadConversationsFromStorage();
    
    // If no conversations exist, create a welcome conversation
    if (savedConversations.length === 0) {
      const welcomeConversation: Conversation = {
        id: Date.now().toString(),
        title: 'Welcome to Dutugamunu.ai',
        messages: [
          {
            id: '1',
            type: 'assistant',
            content: 'Hello! I\'m your AI assistant. I can help you with text generation, image creation, and audio synthesis. Try asking me anything!',
            timestamp: new Date(),
          }
        ],
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      const initialConversations = [welcomeConversation];
      setConversations(initialConversations);
      setCurrentConversationId(welcomeConversation.id);
      setMessages(welcomeConversation.messages);
      saveConversationsToStorage(initialConversations);
    } else {
      setConversations(savedConversations);
      
      // If there are conversations, load the most recent one
      const mostRecent = savedConversations.reduce((latest, current) => 
        current.updatedAt > latest.updatedAt ? current : latest
      );
      setCurrentConversationId(mostRecent.id);
      setMessages(mostRecent.messages);
    }
  }, []);

  // Auto-save conversation when messages change
  useEffect(() => {
    if (currentConversationId && messages.length > 0) {
      const timeoutId = setTimeout(saveCurrentConversation, 1000);
      return () => clearTimeout(timeoutId);
    }
  }, [messages, currentConversationId]);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden" 
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar - Hidden on mobile, shown on desktop */}
      <div className={`
        fixed md:static inset-y-0 left-0 z-50 md:z-auto
        w-80 bg-card border-r border-border flex flex-col h-full
        transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
        md:translate-x-0 transition-transform duration-200 ease-in-out
      `}>
        {/* Mobile Sidebar Header */}
        <div className="md:hidden p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold">Dutugamunu.ai</h1>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(false)}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="p-6 border-b border-border">
          <div className="hidden md:flex items-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold">Dutugamunu.ai</h1>
          </div>
          <div className="space-y-2">
            <Button variant="outline" onClick={() => { createNewConversation(); setIsSidebarOpen(false); }} className="w-full justify-start">
              <MessageSquare className="w-4 h-4 mr-2" />
              New Chat
            </Button>
            <Button variant="outline" onClick={clearChat} className="w-full justify-start">
              <List className="w-4 h-4 mr-2" />
              Clear Current
            </Button>
            <Button variant="outline" onClick={() => {
              // Clear all conversations
              if (confirm('Clear all conversations?')) {
                localStorage.removeItem('pollinations-conversations');
                setConversations([]);
                setCurrentConversationId(null);
                setMessages([]);
                setIsSidebarOpen(false);
              }
            }} className="w-full justify-start">
              <X className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          </div>
        </div>

        {/* Conversation History */}
        <div className="flex-1 p-6 border-b border-border flex flex-col min-h-0">
          <div className="flex items-center justify-between mb-3 flex-shrink-0">
            <h3 className="text-sm font-medium text-muted-foreground">Conversations</h3>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{conversations.length}</span>
              {currentConversationId && (
                <span className="text-xs text-primary">●</span>
              )}
            </div>
          </div>
          <ScrollArea className="flex-1 min-h-0">
            <div className="space-y-2">
              {conversations.length === 0 ? (
                <div className="text-xs text-muted-foreground text-center py-4">No conversations yet</div>
              ) : (
                conversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      currentConversationId === conversation.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted hover:bg-muted/80'
                    }`}
                    onClick={() => { 
                      loadConversation(conversation.id); 
                      setIsSidebarOpen(false); 
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">
                          {conversation.title}
                        </div>
                        <div className="text-xs opacity-70 mt-1">
                          {conversation.messages.length} messages • {conversation.updatedAt.toLocaleDateString()}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 opacity-70 hover:opacity-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm('Delete this conversation?')) {
                            deleteConversation(conversation.id);
                          }
                        }}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        <div className="p-6 border-t border-border">
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Generation Mode</h3>
          <Tabs value={selectedModel} onValueChange={setSelectedModel} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="text" className="flex items-center gap-1 text-xs">
                <MessageSquare className="w-3 h-3" />
                Text
              </TabsTrigger>
              <TabsTrigger value="image" className="flex items-center gap-1 text-xs">
                <Image className="w-3 h-3" />
                Image
              </TabsTrigger>
              <TabsTrigger value="audio" className="flex items-center gap-1 text-xs">
                <Music className="w-3 h-3" />
                Audio
              </TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="mt-4">
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Text Model</h4>
                {loadingModels ? (
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    <div className="text-xs text-muted-foreground">Loading models...</div>
                  </div>
                ) : (
                  <Select value={selectedTextModel} onValueChange={setSelectedTextModel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select text model" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableModels.text?.map((model, index) => (
                        <SelectItem key={index} value={typeof model === 'string' ? model : model.id || model.name || `model-${index}`}>
                          {typeof model === 'string' ? model : model.name || model.id || `Model ${index + 1}`}
                        </SelectItem>
                      ))}
                      <SelectItem value="default">Default</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>
            </TabsContent>

            <TabsContent value="image" className="mt-4">
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Image Size</h4>
                <Select value={imageSize} onValueChange={setImageSize}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    {imageSizes.map((size) => (
                      <SelectItem key={size.id} value={size.id}>
                        {size.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            <TabsContent value="audio" className="mt-4">
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Voice</h4>
                <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select voice" />
                  </SelectTrigger>
                  <SelectContent>
                    {voices.map((voice) => (
                      <SelectItem key={voice.id} value={voice.id}>
                        {voice.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Real-time Feeds Section */}
        <div className="p-6 border-t border-border">
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Recent Activity</h3>
          <Tabs defaultValue="text" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="text" className="text-xs">Text</TabsTrigger>
              <TabsTrigger value="image" className="text-xs">Images</TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="mt-3">
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {loadingFeeds ? (
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    <div className="text-xs text-muted-foreground">Loading feeds...</div>
                  </div>
                ) : feeds.text.length > 0 ? (
                  feeds.text.slice(0, 3).map((item, index) => (
                    <div key={index} className="p-2 bg-muted rounded text-xs">
                      <div className="font-medium truncate">
                        {typeof item === 'string' ? item : item.prompt || item.content || 'Text item'}
                      </div>
                      <div className="text-muted-foreground text-xs mt-1">
                        {new Date().toLocaleTimeString()}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-muted-foreground">No recent activity</div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="image" className="mt-3">
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {loadingFeeds ? (
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    <div className="text-xs text-muted-foreground">Loading feeds...</div>
                  </div>
                ) : feeds.image.length > 0 ? (
                  feeds.image.slice(0, 3).map((item, index) => (
                    <div key={index} className="p-2 bg-muted rounded text-xs">
                      <div className="font-medium truncate">
                        {typeof item === 'string' ? item : item.prompt || item.content || 'Image item'}
                      </div>
                      <div className="text-muted-foreground text-xs mt-1">
                        {new Date().toLocaleTimeString()}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-muted-foreground">No recent activity</div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Mobile Header */}
        <div className="md:hidden p-4 border-b border-border flex items-center justify-between bg-card flex-shrink-0">
          <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(true)}>
            <Menu className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h1 className="text-lg font-bold">Dutugamunu.ai</h1>
          </div>
          <div className="w-8" /> {/* Spacer for alignment */}
        </div>
        
        {/* Tabbed Interface */}
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          <Tabs defaultValue="chat" className="flex-1 flex flex-col h-full">
            <div className="border-b border-border px-4 md:px-6 pt-4 flex-shrink-0">
              <TabsList className="grid w-full max-w-md grid-cols-2">
                <TabsTrigger value="chat" className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Chat
                </TabsTrigger>
                <TabsTrigger value="conversations" className="flex items-center gap-2">
                  <List className="w-4 h-4" />
                  Conversations
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="chat" className="flex-1 flex flex-col data-[state=active]:flex h-full overflow-hidden">
              {/* Conversation Selector */}
              <div className="border-b border-border px-4 md:px-6 py-3 flex-shrink-0">
                <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <span className="text-sm font-medium whitespace-nowrap">Current Conversation:</span>
                    <Select value={currentConversationId || "new-conversation"} onValueChange={(value) => {
                      if (value === "new-conversation") {
                        createNewConversation();
                      } else {
                        loadConversation(value);
                      }
                    }}>
                      <SelectTrigger className="w-full sm:w-64">
                        <SelectValue placeholder="Select a conversation" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new-conversation">+ New Conversation</SelectItem>
                        {conversations.map((conversation) => (
                          <SelectItem key={conversation.id} value={conversation.id}>
                            {conversation.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap">
                    {conversations.length} conversation{conversations.length !== 1 ? 's' : ''}
                  </div>
                </div>
              </div>

              {/* Messages - Scrollable Area */}
              <div className="flex-1 h-full overflow-hidden">
                <ScrollArea className="h-full p-4 md:p-6">
                  <div className="max-w-4xl mx-auto space-y-4 pb-4">
                    {messages.length === 0 && (
                      <div className="text-center py-12">
                        <Sparkles className="w-12 h-12 text-primary mx-auto mb-4" />
                        <h2 className="text-2xl font-bold mb-2">Welcome to Dutugamunu.ai</h2>
                        <p className="text-muted-foreground">
                          Start a conversation with AI using text, image, or audio generation
                        </p>
                      </div>
                    )}

                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex gap-3 ${
                          message.type === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[90%] md:max-w-[70%] rounded-lg p-4 ${
                            message.type === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          {message.mediaType === "image" && message.mediaUrl && (
                            <div className="mb-3 relative group">
                              <img
                                src={message.mediaUrl}
                                alt={`Generated image for: ${message.content}`}
                                className="rounded-lg max-w-full h-auto shadow-lg"
                                onError={(e) => {
                                  e.currentTarget.src = '';
                                  e.currentTarget.style.display = 'none';
                                }}
                              />
                              <Button
                                size="sm"
                                variant="secondary"
                                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => downloadImage(message.mediaUrl!, `generated-image-${message.id}.png`)}
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                          {message.mediaType === "audio" && message.mediaUrl && (
                            <div className="mb-3">
                              <audio 
                                controls 
                                className="w-full"
                                preload="metadata"
                              >
                                <source src={message.mediaUrl} type={message.contentType || 'audio/mpeg'} />
                                Your browser does not support the audio element.
                              </audio>
                            </div>
                          )}
                          <div className="flex items-start gap-2">
                            <p className="text-sm whitespace-pre-wrap flex-1">{message.content}</p>
                            {message.type === "assistant" && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="opacity-70 hover:opacity-100 transition-opacity p-1 h-6 w-6"
                                onClick={() => copyToClipboard(message.content)}
                                title="Copy to clipboard"
                              >
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                </svg>
                              </Button>
                            )}
                          </div>
                          <p className="text-xs opacity-70 mt-2">
                            {message.timestamp.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex gap-3 justify-start">
                        <div className="max-w-[70%] rounded-lg p-4 bg-muted">
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                            <span className="text-sm">Generating response...</span>
                            {isGenerating && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="ml-2 p-1 h-6 w-6"
                                onClick={stopGeneration}
                                title="Stop generation"
                              >
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                                </svg>
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </div>

              {/* Input Area - Fixed at bottom */}
              <div className="border-t border-border p-3 md:p-4 bg-background flex-shrink-0">
                <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
                  {/* Model Selection - Compact for mobile */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedModel === "text" && (
                      <Select value={selectedTextModel} onValueChange={setSelectedTextModel}>
                        <SelectTrigger className="w-full sm:w-40 h-8 text-xs">
                          <SelectValue placeholder="Model" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableModels.text?.map((model, index) => (
                            <SelectItem key={index} value={typeof model === 'string' ? model : model.id || model.name || `model-${index}`}>
                              {typeof model === 'string' ? model : model.name || model.id || `Model ${index + 1}`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    {selectedModel === "image" && (
                      <Select value={imageSize} onValueChange={setImageSize}>
                        <SelectTrigger className="w-full sm:w-32 h-8 text-xs">
                          <SelectValue placeholder="Size" />
                        </SelectTrigger>
                        <SelectContent>
                          {imageSizes.map((size) => (
                            <SelectItem key={size.id} value={size.id}>
                              {size.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    {selectedModel === "audio" && (
                      <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                        <SelectTrigger className="w-full sm:w-32 h-8 text-xs">
                          <SelectValue placeholder="Voice" />
                        </SelectTrigger>
                        <SelectContent>
                          {voices.map((voice) => (
                            <SelectItem key={voice.id} value={voice.id}>
                              {voice.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                  
                  {/* Input with Send Button Inside */}
                  <div className="relative">
                    <Textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder={
                        selectedModel === "image"
                          ? "Describe an image to generate..."
                          : selectedModel === "audio"
                          ? "Describe audio to generate..."
                          : "Type your message..."
                      }
                      className="pr-12 resize-none"
                      rows={2}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSubmit(e);
                        }
                      }}
                    />
                    <Button 
                      type="submit" 
                      disabled={isLoading || !input.trim()} 
                      className="absolute bottom-2 right-2 h-8 w-8 p-0 rounded-full"
                      size="sm"
                    >
                      {isLoading ? (
                        <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send className="w-3 h-3" />
                      )}
                    </Button>
                  </div>
                  
                  {/* Status badges - more compact */}
                  <div className="flex flex-wrap items-center gap-1 mt-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-xs px-2 py-0">
                      {selectedModel === "text"
                        ? "Text"
                        : selectedModel === "image"
                        ? "Image"
                        : "Audio"}
                    </Badge>
                    {selectedModel === "text" && (
                      <Badge variant="outline" className="text-xs px-2 py-0 hidden sm:inline-flex">
                        {selectedTextModel}
                      </Badge>
                    )}
                    {selectedModel === "image" && (
                      <Badge variant="outline" className="text-xs px-2 py-0 hidden sm:inline-flex">
                        {imageSize}
                      </Badge>
                    )}
                    {selectedModel === "audio" && (
                      <Badge variant="outline" className="text-xs px-2 py-0 hidden sm:inline-flex">
                        {selectedVoice}
                      </Badge>
                    )}
                  </div>
                </form>
              </div>
            </TabsContent>

            <TabsContent value="conversations" className="flex-1 data-[state=active]:flex h-full">
              <div className="flex-1 p-4 md:p-6 h-full">
                <div className="max-w-6xl mx-auto h-full flex flex-col">
                  <div className="mb-6 flex-shrink-0">
                    <h2 className="text-2xl font-bold mb-2">Your Conversations</h2>
                    <p className="text-muted-foreground">
                      Manage your chat history and view previous conversations.
                    </p>
                  </div>
                  
                  <div className="flex-1 h-full overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-4 pb-4">
                        {conversations.length === 0 ? (
                          <div className="text-center py-12">
                            <MessageSquare className="w-12 h-12 text-primary mx-auto mb-4 opacity-50" />
                            <h3 className="text-lg font-medium mb-2">No conversations yet</h3>
                            <p className="text-muted-foreground mb-4">
                              Start a new conversation to see it appear here.
                            </p>
                            <Button 
                              onClick={() => {
                                createNewConversation();
                                // Switch to chat tab
                                const chatTab = document.querySelector('[value="chat"]') as HTMLElement;
                                if (chatTab) chatTab.click();
                              }}
                            >
                              <MessageSquare className="w-4 h-4 mr-2" />
                              Start New Chat
                            </Button>
                          </div>
                        ) : (
                          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                            {conversations.map((conversation) => (
                              <Card 
                                key={conversation.id} 
                                className={`cursor-pointer transition-colors hover:shadow-md ${
                                  currentConversationId === conversation.id 
                                    ? 'ring-2 ring-primary' 
                                    : ''
                                }`}
                                onClick={() => {
                                  loadConversation(conversation.id);
                                  // Switch to chat tab
                                  const chatTab = document.querySelector('[value="chat"]') as HTMLElement;
                                  if (chatTab) chatTab.click();
                                }}
                              >
                                <CardHeader className="pb-3">
                                  <div className="flex items-start justify-between">
                                    <CardTitle className="text-sm font-medium line-clamp-2">
                                      {conversation.title}
                                    </CardTitle>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-6 w-6 p-0 opacity-70 hover:opacity-100 flex-shrink-0 ml-2"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        if (confirm('Delete this conversation?')) {
                                          deleteConversation(conversation.id);
                                        }
                                      }}
                                    >
                                      ×
                                    </Button>
                                  </div>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-2">
                                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                                      <span>{conversation.messages.length} messages</span>
                                      <span>{conversation.updatedAt.toLocaleDateString()}</span>
                                    </div>
                                    {conversation.messages.length > 0 && (
                                      <div className="text-xs text-muted-foreground line-clamp-2">
                                        {conversation.messages[conversation.messages.length - 1].content}
                                      </div>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}