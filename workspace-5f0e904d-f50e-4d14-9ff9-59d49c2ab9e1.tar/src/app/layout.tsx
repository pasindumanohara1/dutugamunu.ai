import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Dutugamunu.ai - AI-Powered Conversation",
  description: "Chat with AI using Pollinations.AI APIs for text, image, and audio generation",
  keywords: ["Dutugamunu.ai", "Chat", "AI", "Text Generation", "Image Generation", "Audio Generation"],
  authors: [{ name: "Dutugamunu.ai" }],
  openGraph: {
    title: "Dutugamunu.ai",
    description: "AI-powered conversation with text, image, and audio generation",
    url: "https://dutugamunu.ai",
    siteName: "Dutugamunu.ai",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Dutugamunu.ai",
    description: "AI-powered conversation with text, image, and audio generation",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
