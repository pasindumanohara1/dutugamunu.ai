#!/bin/bash

# Script to create a downloadable archive of the entire project
# This will create a tar.gz file containing all project files

echo "Creating project archive..."

# Get the current directory name
PROJECT_NAME=$(basename "$(pwd)")
ARCHIVE_NAME="${PROJECT_NAME}-$(date +%Y%m%d-%H%M%S).tar.gz"

# Create the archive, excluding node_modules and other unnecessary files
tar -czf "$ARCHIVE_NAME" \
    --exclude="node_modules" \
    --exclude=".git" \
    --exclude=".next" \
    --exclude="*.log" \
    --exclude="dist" \
    --exclude="build" \
    --exclude=".DS_Store" \
    --exclude="*.tmp" \
    --exclude="*.temp" \
    .

echo "Archive created: $ARCHIVE_NAME"
echo "Size: $(du -h "$ARCHIVE_NAME" | cut -f1)"
echo ""
echo "You can download this file using:"
echo "  scp $ARCHIVE_NAME user@host:/path/to/destination"
echo ""
echo "Or if you're using a local environment, the file is ready at:"
echo "  $(pwd)/$ARCHIVE_NAME"